package com.example.demo;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component
public class Girl {

    Outfit outfit;

    public Girl(@Qualifier("skirt") Outfit outfit) {
        this.outfit = outfit;
    }

    @PostConstruct
    public void postContruct(){
        System.out.println("Đối tương Girl tạo xong thì sẽ chạy hàm này");
    }

    @PreDestroy
    public void preDestroy(){
        System.out.println("Hàm sẽ được gọi trước khi xóa bean");
    }

    public Outfit getOutfit() {
        return outfit;
    }

//    public void setOutfit(Outfit outfit) {
//        this.outfit = outfit;
//    }
}
