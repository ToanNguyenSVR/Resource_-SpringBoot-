package com.example.demo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

/**
 * Đánh dấu class bằng @Component
 * Class này sẽ được Spring hiểu là 1 bean(dependency) và sẽ được Spring boot quản lý
 * */
@Component("bikini")
public class Bikini implements Outfit{
    @Override
    public void wear() {
        System.out.println("Đã mặc bikini");
    }
}
