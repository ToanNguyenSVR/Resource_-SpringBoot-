package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class App {

    public static void main(String[] args) {
        //ApplicationContext chứa toàn bộ dependency của project
        ApplicationContext context = SpringApplication.run(App.class, args);

        //Lấy bean ra
        Outfit outfit= (Outfit) context.getBean("skirt");


        //in nó ra
        System.out.println("Outfit Instance: "+outfit);
        outfit.wear();

        Girl girl = context.getBean(Girl.class);
        //in girl ra
        System.out.println("Girl Instance: "+girl);
        System.out.println("Outfit of girl"+girl.outfit);
        girl.outfit.wear();
        ((ConfigurableApplicationContext) context).getBeanFactory().destroyBean(girl);


    }

}
