package com.example.demo;

import org.springframework.stereotype.Component;

@Component("skirt")
public class Skirt implements Outfit{
    @Override
    public void wear() {
        System.out.println("Đã mặc váy");
    }
}
