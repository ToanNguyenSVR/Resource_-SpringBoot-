package com.example.demo;

public interface GirlReponsitory {
    //Tim Cô gái theo tên
    public Girl getGirlByName(String name);
}
