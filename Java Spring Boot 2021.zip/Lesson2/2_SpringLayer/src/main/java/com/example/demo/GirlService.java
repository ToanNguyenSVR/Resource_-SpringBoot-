package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GirlService {

    @Autowired
    private GirlReponsitory girlReponsitory;

    public Girl getGirlByName(String name){

        //Gọi xuống tầng responsitory để lấy cô gái có name trong database
        return girlReponsitory.getGirlByName(name);
    }
}
