package com.example.demo2;

import org.springframework.stereotype.Component;

@Component
public class Boy {

    private String name;

    public Boy() {
        this.name = "Quan";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString(){
        return "Boy("+this.name+")";
    }
}
