package com.example.demo;

import org.springframework.stereotype.Repository;

@Repository
public class GirlResponsitoryImpl implements GirlReponsitory{
    @Override
    public Girl getGirlByName(String name) {
        //giả sử có 1 cô gái tên Nhân
        //Tìm trong csdl cô gái có tên là Nhân và trả về
        return new Girl("Nhân");
    }
}
