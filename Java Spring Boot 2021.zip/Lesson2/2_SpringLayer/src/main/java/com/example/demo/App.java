package com.example.demo;

import com.example.demo.others.OtherGirl;
import com.example.demo2.Boy;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication(scanBasePackages = "com.example.*")
//@ComponentScan("com.example.*")
public class App {

    public static void main(String[] args) {
       ApplicationContext context =  SpringApplication.run(App.class, args);

       //lấy ra girlservice
//        GirlService girlService = context.getBean(GirlService.class);
//
//        Girl girl = girlService.getGirlByName("Bảo");
//
//        System.out.println(girl);

        Boy boy = context.getBean(Boy.class);
        System.out.println(boy);
    }

}
