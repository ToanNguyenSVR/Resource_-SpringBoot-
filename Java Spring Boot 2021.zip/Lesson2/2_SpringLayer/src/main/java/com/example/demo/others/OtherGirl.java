package com.example.demo.others;

import org.springframework.stereotype.Component;

@Component
public class OtherGirl {

    private String name;

    public OtherGirl() {
        this.name = "Quan";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString(){
        return "Girl("+this.name+")";
    }
}
