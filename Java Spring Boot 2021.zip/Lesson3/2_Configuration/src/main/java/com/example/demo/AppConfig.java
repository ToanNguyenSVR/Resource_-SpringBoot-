package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Value("${mysql.url}")
    String mySqlUrl;

    @Bean("mysql")
    DatabaseConnector mysqlConfigure(){
         DatabaseConnector mySqlConnector =  new MySqlConnector();
        mySqlConnector.setUrl(mySqlUrl);
         //set username, password
        return mySqlConnector;
    }

    @Bean("mongodb")
    DatabaseConnector mongoDBConfigure(){
        DatabaseConnector mongoDBConnector =  new MongoDBConnector();
        mongoDBConnector.setUrl("mongodb://localhost:27017/demoDB");
        //set username, password
        return mongoDBConnector;
    }
    @Bean("postgre")
    DatabaseConnector postgreSQLConfigure(){
        DatabaseConnector postgreSqlConnector =  new PostgreSQLConnector();
        postgreSqlConnector.setUrl("jdbc:postgree://localhost/demoDB");
        //set username, password
        return postgreSqlConnector;
    }
}
