package com.example.demo;

public class MySqlConnector extends DatabaseConnector{

    @Override
    public void connect() {
        System.out.println("Đã kết nối với mysql: "+this.getUrl());
    }
}
