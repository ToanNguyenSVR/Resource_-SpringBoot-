package com.example.demo;

public class PostgreSQLConnector extends DatabaseConnector {
    @Override
    public void connect() {
        System.out.println("Đã kết nối với PostgreSQL: "+this.getUrl());
    }
}
