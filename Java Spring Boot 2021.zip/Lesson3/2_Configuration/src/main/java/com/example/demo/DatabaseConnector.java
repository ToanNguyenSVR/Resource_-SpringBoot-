package com.example.demo;

public abstract class DatabaseConnector {
    private String url;

    public DatabaseConnector() {
    }

    public DatabaseConnector(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    //Hàm kết nối với database bất kì
    public abstract void connect();
}
