package com.example.demo;

public class MongoDBConnector extends DatabaseConnector{
    @Override
    public void connect() {
        System.out.println("Đã kết nối tới Mongodb: "+this.getUrl());
    }
}
