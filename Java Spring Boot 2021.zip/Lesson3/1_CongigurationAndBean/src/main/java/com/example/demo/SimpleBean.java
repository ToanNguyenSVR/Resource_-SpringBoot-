package com.example.demo;

//Một class bình thường, không sử dung @Component
public class SimpleBean {
    private String name;

    public SimpleBean(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "This is simple bean with name: "+name;
    }
}
