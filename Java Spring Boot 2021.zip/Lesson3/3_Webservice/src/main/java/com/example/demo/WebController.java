package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;

//Đánh dấu đây là 1 controller
//Là nơi tiếp nhận các request từ người dùng
@Controller
public class WebController {

    //Đón nhận các request có method là get
    @GetMapping("/") //url là "/"
    public String index(){
        return "index";
    }

    @PostMapping("/hello")
    public String hello(@RequestParam(name = "fullname") String name, Model model){
        model.addAttribute("name",name);
        return "hello";
    }

    @GetMapping("/about")
    public String about(){
        return "about";
    }
}
