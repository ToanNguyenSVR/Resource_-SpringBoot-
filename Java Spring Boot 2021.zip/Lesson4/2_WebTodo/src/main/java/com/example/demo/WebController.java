package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Controller
public class WebController {
    //Sử dụng để lưu danh sách công việc
    //Thay thế cho database
    //demo
    List<Todo> todoList = new CopyOnWriteArrayList<>();

    //Hiển thị lên danh sách công việc

    @GetMapping("/todos")
    public String listAllTodo(Model model){
        model.addAttribute("todoList",todoList);

        //Trả về template todo.html
        return "todo";
    }

    @GetMapping("/addTodo")
    public String addTodo(Model model){
        model.addAttribute("todo",new Todo());
        return "addTodo";
    }

    @PostMapping("/addTodo")
    public String saveTodo(@ModelAttribute Todo todo){
        todoList.add(todo);
        return "redirect:todos";
    }
}
