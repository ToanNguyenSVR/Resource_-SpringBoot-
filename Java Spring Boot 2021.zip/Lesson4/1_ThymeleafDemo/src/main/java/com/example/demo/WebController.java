package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class WebController {

    @GetMapping("/info")
    public String info(Model model){
        List<Infomation> profiles = new ArrayList<>();
        profiles.add(new Infomation("fullname","Le Hong Quan"));
        profiles.add(new Infomation("email","lehongquan15a@gmail.com"));
        profiles.add(new Infomation("age","22 years old"));
        model.addAttribute("profile",profiles);
        return "info";
    }
}
