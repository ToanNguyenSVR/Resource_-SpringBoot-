public class Main {
    public static void main(String[] args) {
        Outfit bikini = new Bikini(); //tạo đối tượng bikini
        Outfit skirt = new SkirtVeryShort();
        Outfit nothing = new Naked();

         Girl ngoctrinh = new Girl(bikini); //mặc nó vào cho ngọc trinh
        ngoctrinh.showOutfit();
        ngoctrinh.setOutfit(nothing);
        ngoctrinh.showOutfit();
    }
}
