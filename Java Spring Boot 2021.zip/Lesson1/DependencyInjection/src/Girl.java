public class Girl {
    private Outfit outfit; //Mỗi cô gái sẽ có 1 bộ outfit

    public Girl(Outfit outfit) {
        this.outfit = outfit; //mặc outfit vào cho cô gái đấy
    }
    public void showOutfit(){
        outfit.wear();
    }

    public Outfit getOutfit() {
        return outfit;
    }

    public void setOutfit(Outfit outfit) {
        this.outfit = outfit;
    }
}
