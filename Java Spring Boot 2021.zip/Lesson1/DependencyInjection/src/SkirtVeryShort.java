public class SkirtVeryShort implements Outfit{
    @Override
    public void wear() {
        System.out.println("Đã mặc váy ngắn");
    }
}
