public interface Outfit {
    public void wear();
}
