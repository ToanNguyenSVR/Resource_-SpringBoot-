public class Bikini implements  Outfit{
    @Override
    public void wear() {
        System.out.println("Đã mặc bikini");
    }
}
