public class Main {
    public static void main(String[] args) {
        SortAlgorithm bubbleSortAlgorithm = new BubbleSort();
        SortAlgorithm quickSortAlgorithm = new QuickSort();
        VerryComplex bussiness1 = new VerryComplex(bubbleSortAlgorithm);
        VerryComplex bussiness2 = new VerryComplex(quickSortAlgorithm);
        int a[]= new int[100];
        bussiness1.complexBusiness(a);
        bussiness2.complexBusiness(a);
        bussiness2.setSortAlgorithm(bubbleSortAlgorithm);
        bussiness2.complexBusiness(a);
    }
}
