public class QuickSort implements SortAlgorithm{
    @Override
    public void sort(int[] arr) {
        //code any things

        System.out.println("Đã được sắp xếp với quick sort");
    }
}
