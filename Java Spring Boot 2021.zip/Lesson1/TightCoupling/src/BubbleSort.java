public class BubbleSort implements SortAlgorithm{

    public void sort (int arr[]){
        //1 tá thao tác sắp xếp
        System.out.println("Đã sắp xếp bằng thuật toán nổi bọt");
    }
}
