//Class phức tạp vãi nồi
//Xử lý việc sắp xếp
public class VerryComplex {
    private  SortAlgorithm sortAlgorithm ;

    public VerryComplex(SortAlgorithm sortAlgorithm) {
       this.sortAlgorithm  = sortAlgorithm;
    }

    public SortAlgorithm getSortAlgorithm() {
        return sortAlgorithm;
    }

    public void setSortAlgorithm(SortAlgorithm sortAlgorithm) {
        this.sortAlgorithm = sortAlgorithm;
    }

    public void complexBusiness(int arr[]){
        sortAlgorithm.sort(arr);

        // code any things
    }
}
