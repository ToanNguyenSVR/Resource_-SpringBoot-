public interface SortAlgorithm {
    public void sort(int arr[]);

}
